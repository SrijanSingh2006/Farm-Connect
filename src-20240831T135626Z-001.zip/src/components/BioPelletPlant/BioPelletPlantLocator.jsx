// src/BioPelletLocator.js
import React, { useState } from 'react';
import axios from 'axios';

const BioPelletLocator = () => {
    const [pincode, setPincode] = useState('');
    const [plants, setPlants] = useState([]);
    const [error, setError] = useState(null);

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.get('http://localhost:5000/api/nearest-plants', {
                params: { pincode }
            });
            setPlants(response.data);
            setError(null);
        } catch (error) {
            setError('Error fetching plants');
            setPlants([]);
        }
    };

    return (
        <div>
            <h1>Find Nearest Bio-Pellet Plants</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Pincode:</label>
                    <input
                        type="text"
                        value={pincode}
                        onChange={(e) => setPincode(e.target.value)}
                    />
                </div>
                <button type="submit">Find Plants</button>
            </form>
            {error && <p>{error}</p>}
            <ul>
                {plants.map((plant) => (
                    <li key={plant.id}>
                        {plant.name} - {plant.distance} km away
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default BioPelletLocator;