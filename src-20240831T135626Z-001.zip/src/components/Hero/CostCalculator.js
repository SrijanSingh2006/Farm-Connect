document.getElementById('calculate-btn').addEventListener('click', function() {
    const weight = parseFloat(document.getElementById('weight').value);
    const costPerKg = 6; // Cost per kg
    const resultElement = document.getElementById('result');
  
    if (isNaN(weight) || weight <= 0) {
      resultElement.textContent = 'Please enter a valid weight.';
    } else {
      const cost = weight * costPerKg;
      resultElement.textContent = `Cost: ₹${cost.toFixed(2)}`;
    }
  });